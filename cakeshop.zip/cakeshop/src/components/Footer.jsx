import React from "react";
import { Link } from "react-router-dom";

export default function Footer() {
  return (
    <>
      {/* <!-- info section --> */}
      <section className="info_section layout_padding">
        <div className="container">
          <div className="info_social">
            <div>
              <Link to="">
                <img src="images/fb.png" alt="" />
              </Link>
            </div>
            <div>
              <Link to="">
                <img src="images/twitter.png" alt="" />
              </Link>
            </div>
            <div>
              <Link to="">
                <img src="images/linkedin.png" alt="" />
              </Link>
            </div>
            <div>
              <Link to="">
                <img src="images/instagram.png" alt="" />
              </Link>
            </div>
          </div>
          <div>
            <p>
              Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
              eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut
              enim ad minim veniam, quis nostrud exercitation ullamco laboris
              nisi
            </p>
          </div>
        </div>
      </section>

      {/* <!-- end info_section --> */}

      {/* <!-- footer section --> */}
      <section class="container-fluid footer_section">
        <div class="container">
          <div class="row">
            <div class="col-lg-7 col-md-9 mx-auto">
              <p>
                &copy;2023 <span id="currentDate"></span> All Rights Reserved.
                <a href="https://niyooshawebsites.com">
                  &nbsp; Designed By Babai Bose
                </a>
              </p>
            </div>
          </div>
        </div>
      </section>
      {/* <!-- footer section --> */}
    </>
  );
}
