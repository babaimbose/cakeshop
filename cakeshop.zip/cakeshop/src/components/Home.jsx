import React from "react";
import { Link } from "react-router-dom";
import Contact from "./Contact";
import Hero from "./Hero";
import Slider from "./Slider";

export default function Home() {
  return (
    <>
      <Slider />
      {/* <!-- product section --> */}
      <section className="product_section layout_padding">
        <div className="container">
          <div className="heading_container">
            <h2>Our products</h2>
            <p>
              There are many variations of passages of Lorem Ipsum available,
              but the majority have
            </p>
          </div>

          <div className="product_container">
            <div className="box_container">
              <div className="img-box">
                <img src="images/p1.png" className="img1" alt="" />
              </div>
              <div className="box">
                <div className="detail-box">
                  <h5>classic Treat</h5>
                  <p>
                    There are many variations of passages of Lorem Ipsum
                    available, butdon't look even slightly believable.
                  </p>
                  <Link href="">
                    <img src="images/right-arrow.png" alt="" />
                  </Link>
                </div>
              </div>
            </div>
            <div className="box_container">
              <div className="img-box">
                <img src="images/p2.png" className="img1" alt="" />
              </div>
              <div className="box active">
                <div className="detail-box">
                  <h5>Party Special</h5>
                  <p>
                    There are many variations of passages of Lorem Ipsum
                    available, butdon't look even slightly believable.
                  </p>
                  <Link href="">
                    <img src="images/right-arrow.png" alt="" />
                  </Link>
                </div>
              </div>
            </div>
            <div className="box_container">
              <div className="img-box">
                <img src="images/p3.png" className="img1" alt="" />
              </div>
              <div className="box">
                <div className="detail-box">
                  <h5>Sweet Treat</h5>
                  <p>
                    There are many variations of passages of Lorem Ipsum
                    available, butdon't look even slightly believable.
                  </p>
                  <Link href="">
                    <img src="images/right-arrow.png" alt="" />
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      {/* <!-- end product section --> */}

      {/* <!-- about section --> */}
      <section className="about_section layout_padding-bottom">
        <div className="container">
          <div className="row">
            <div className="col-md-6">
              <div className="img-box pr-md-4 pr-lg-5">
                <img src="images/about-img.png" alt="" />
              </div>
            </div>
            <div className="col-md-6">
              <div className="detail-box">
                <div className="heading_container">
                  <h2>About Us</h2>
                </div>
                <p>
                  Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed
                  do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                  Ut enim ad minim veniam, quis nostrud
                </p>
                <Link href="">Read More</Link>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* <!-- end about section --> */}

      {/* <!-- client section --> */}
      <section className="client_section layout_padding">
        <div className="container">
          <div className="heading_container">
            <h2>What Customer Says</h2>
          </div>
        </div>
        <div
          id="carouselExample2Indicators"
          className="carousel slide"
          data-ride="carousel"
        >
          <ol className="carousel-indicators">
            <li
              data-target="#carouselExample2Indicators"
              data-slide-to="0"
              className="active"
            ></li>
            <li
              data-target="#carouselExample2Indicators"
              data-slide-to="1"
            ></li>
            <li
              data-target="#carouselExample2Indicators"
              data-slide-to="2"
            ></li>
          </ol>
          <div className="carousel-inner">
            <div className="carousel-item active">
              <div className="container">
                <div className="client_container">
                  <div className="row">
                    <div className="col-md-6">
                      <div className="client_box">
                        <div className="img_box">
                          <img src="images/client-1.png" />
                        </div>
                        <div className="detail_box">
                          <h5>John Doe</h5>
                          <p>
                            Lorem ipsum dolor sit amet, consectetur adipiscing
                            elit, sed do eiusmod tempor incididunt ut labore et
                            dolore magna aliqua. Ut enim ad minim veniaLorem
                            ipsum dolor sit amet, consectetur adipiscing elit,
                            sed do eiusmod
                          </p>
                        </div>
                      </div>
                    </div>
                    <div className="col-md-6">
                      <div className="client_box">
                        <div className="img_box">
                          <img src="images/client-2.png" />
                        </div>
                        <div className="detail_box">
                          <h5>Alice Kent</h5>
                          <p>
                            Lorem ipsum dolor sit amet, consectetur adipiscing
                            elit, sed do eiusmod tempor incididunt ut labore et
                            dolore magna aliqua. Ut enim ad minim veniaLorem
                            ipsum dolor sit amet, consectetur adipiscing elit,
                            sed do eiusmod
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="carousel-item ">
              <div className="container">
                <div className="client_container">
                  <div className="row">
                    <div className="col-md-6">
                      <div className="client_box">
                        <div className="img_box">
                          <img src="images/client-1.png" />
                        </div>
                        <div className="detail_box">
                          <h5>John Doe</h5>
                          <p>
                            Lorem ipsum dolor sit amet, consectetur adipiscing
                            elit, sed do eiusmod tempor incididunt ut labore et
                            dolore magna aliqua. Ut enim ad minim veniaLorem
                            ipsum dolor sit amet, consectetur adipiscing elit,
                            sed do eiusmod
                          </p>
                        </div>
                      </div>
                    </div>
                    <div className="col-md-6">
                      <div className="client_box">
                        <div className="img_box">
                          <img src="images/client-2.png" />
                        </div>
                        <div className="detail_box">
                          <h5>Alice Kent</h5>
                          <p>
                            Lorem ipsum dolor sit amet, consectetur adipiscing
                            elit, sed do eiusmod tempor incididunt ut labore et
                            dolore magna aliqua. Ut enim ad minim veniaLorem
                            ipsum dolor sit amet, consectetur adipiscing elit,
                            sed do eiusmod
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="carousel-item ">
              <div className="container">
                <div className="client_container">
                  <div className="row">
                    <div className="col-md-6">
                      <div className="client_box">
                        <div className="img_box">
                          <img src="images/client-1.png" />
                        </div>
                        <div className="detail_box">
                          <h5>John Doe</h5>
                          <p>
                            Lorem ipsum dolor sit amet, consectetur adipiscing
                            elit, sed do eiusmod tempor incididunt ut labore et
                            dolore magna aliqua. Ut enim ad minim veniaLorem
                            ipsum dolor sit amet, consectetur adipiscing elit,
                            sed do eiusmod
                          </p>
                        </div>
                      </div>
                    </div>
                    <div className="col-md-6">
                      <div className="client_box">
                        <div className="img_box">
                          <img src="images/client-2.png" />
                        </div>
                        <div className="detail_box">
                          <h5>Alice Kent</h5>
                          <p>
                            Lorem ipsum dolor sit amet, consectetur adipiscing
                            elit, sed do eiusmod tempor incididunt ut labore et
                            dolore magna aliqua. Ut enim ad minim veniaLorem
                            ipsum dolor sit amet, consectetur adipiscing elit,
                            sed do eiusmod
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      {/* <!-- end client section --> */}

      <Contact />
    </>
  );
}
