import React from "react";
import { Link } from "react-router-dom";

export default function About() {
  return (
    <>
      {/* <!-- about section --> */}
      <section className="about_section layout_padding">
        <div className="container">
          <div className="row">
            <div className="col-md-6">
              <div className="img-box pr-md-4 pr-lg-5">
                <img src="images/about-img.png" alt="" />
              </div>
            </div>
            <div className="col-md-6">
              <div className="detail-box">
                <div className="heading_container">
                  <h2>About Us</h2>
                </div>
                <p>
                  Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed
                  do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                  Ut enim ad minim veniam, quis nostrud
                </p>
                <Link to="">Read More</Link>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* <!-- end about section --> */}
    </>
  );
}
