import React from "react";
import { Link } from "react-router-dom";

export default function Product() {
  return (
    <>
      {/* <!-- product section --> */}
      <section className="product_section layout_padding">
        <div className="container">
          <div className="heading_container">
            <h2>Our products</h2>
            <p>
              There are many variations of passages of Lorem Ipsum available,
              but the majority have
            </p>
          </div>

          <div className="product_container">
            <div className="box_container">
              <div className="img-box">
                <img src="images/p1.png" className="img1" alt="" />
              </div>
              <div className="box">
                <div className="detail-box">
                  <h5>classNameic Treat</h5>
                  <p>
                    There are many variations of passages of Lorem Ipsum
                    available, butdon't look even slightly believable.
                  </p>
                  <Link to="">
                    <img src="images/right-arrow.png" alt="" />
                  </Link>
                </div>
              </div>
            </div>
            <div className="box_container">
              <div className="img-box">
                <img src="images/p2.png" className="img1" alt="" />
              </div>
              <div className="box active">
                <div className="detail-box">
                  <h5>Party Special</h5>
                  <p>
                    There are many variations of passages of Lorem Ipsum
                    available, butdon't look even slightly believable.
                  </p>
                  <Link to="">
                    <img src="images/right-arrow.png" alt="" />
                  </Link>
                </div>
              </div>
            </div>
            <div className="box_container">
              <div className="img-box">
                <img src="images/p3.png" className="img1" alt="" />
              </div>
              <div className="box">
                <div className="detail-box">
                  <h5>Sweet Treat</h5>
                  <p>
                    There are many variations of passages of Lorem Ipsum
                    available, butdon't look even slightly believable.
                  </p>
                  <Link to="">
                    <img src="images/right-arrow.png" alt="" />
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      {/* <!-- end product section --> */}
    </>
  );
}
