import React from "react";
import { Link } from "react-router-dom";

export default function Contact() {
  return (
    <>
      {/* <!-- contact section --> */}

      <section className="contact_section layout_padding">
        <div className="container ">
          <div className="heading_container">
            <h2>Contact Us</h2>
          </div>
        </div>
        <div className="container">
          <div className="row">
            <div className="col-md-8 col-lg-6 mx-auto">
              <form action="">
                <div>
                  <input type="text" placeholder="Name" />
                </div>
                <div>
                  <input type="email" placeholder="Email" />
                </div>
                <div>
                  <input type="text" placeholder="Phone Number" />
                </div>
                <div>
                  <input
                    type="text"
                    className="message-box"
                    placeholder="Message"
                  />
                </div>
                <div className="d-flex justify-content-center">
                  <button>SEND</button>
                </div>
              </form>
            </div>
          </div>
        </div>
        <div className="container">
          <div className="contact_items">
            <Link href="">
              <div className="item ">
                <div className="img-box ">
                  <img src="images/call.png" alt="" />
                </div>
                <div className="detail-box">
                  <p>+02 1234567890</p>
                </div>
              </div>
            </Link>
            <Link href="">
              <div className="item ">
                <div className="img-box ">
                  <img src="images/mail.png" alt="" />
                </div>
                <div className="detail-box">
                  <p>demo@gmail.com</p>
                </div>
              </div>
            </Link>
            <Link href="">
              <div className="item ">
                <div className="img-box ">
                  <img src="images/location.png" alt="" />
                </div>
                <div className="detail-box">
                  <p>Location</p>
                </div>
              </div>
            </Link>
          </div>
        </div>
      </section>

      {/* <!-- end contact section --> */}
    </>
  );
}
