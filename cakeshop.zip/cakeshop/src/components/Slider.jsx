import React from "react";
import { Link } from "react-router-dom";

export default function Slider() {
  return (
    <>
      <div className="hero_area">
        {/* <!-- slider section --> */}
        <section className=" slider_section ">
          <div className="container">
            <div className="row">
              <div className="col-md-6 ">
                <div className="detail_box">
                  <h1>
                    Welcome to <br />
                    Our Cake Shop
                  </h1>
                  <p>
                    There are many variations of passages of Lorem Ipsum
                    available, but the majority have suffered alteration in some
                    form, by injected humour,{" "}
                  </p>
                  <Link to="" className="">
                    Shop Now
                  </Link>
                </div>
              </div>
              <div className="col-lg-5 col-md-6 offset-lg-1">
                <div className="img_container">
                  <div
                    id="carouselExampleIndicators"
                    className="carousel slide"
                    data-ride="carousel"
                  >
                    <ol className="carousel-indicators">
                      <li
                        data-target="#carouselExampleIndicators"
                        data-slide-to="0"
                        className="active"
                      >
                        01
                      </li>
                      <li
                        data-target="#carouselExampleIndicators"
                        data-slide-to="1"
                      >
                        02
                      </li>
                      <li
                        data-target="#carouselExampleIndicators"
                        data-slide-to="2"
                      >
                        03
                      </li>
                    </ol>
                    <div className="carousel-inner">
                      <div className="carousel-item active">
                        <div className="img-box">
                          <img src="images/slider-img1.png" alt="" />
                        </div>
                      </div>
                      <div className="carousel-item">
                        <div className="img-box">
                          <img src="images/slider-img2.png" alt="" />
                        </div>
                      </div>
                      <div className="carousel-item">
                        <div className="img-box">
                          <img src="images/slider-img3.png" alt="" />
                        </div>
                      </div>
                    </div>
                    <div className="carousel_btn-box">
                      <Link
                        className="carousel-control-prev"
                        to="#carouselExampleIndicators"
                        role="button"
                        data-slide="prev"
                      >
                        <span className="sr-only">Previous</span>
                      </Link>
                      <Link
                        className="carousel-control-next"
                        to="#carouselExampleIndicators"
                        role="button"
                        data-slide="next"
                      >
                        <span className="sr-only">Next</span>
                      </Link>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
        {/* <!-- end slider section --> */}
      </div>
    </>
  );
}
