import React from "react";
import Header from "./Header";
import Slider from "./Slider";

export default function Hero() {
  return (
    <>
      <div className="hero_area">
        <Slider />
      </div>
    </>
  );
}
